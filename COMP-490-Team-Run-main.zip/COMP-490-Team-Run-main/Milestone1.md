Team Name- Run

1- 
Team Names-
Osbaldo, Bravo     osbaldo.bravo.056@my.csun.edu   ( Team Leader )
Carlos Martinez    carlos.martinez.959@my.csun.edu
Anthony Jimenez  anthony.jimenez.396@my.csun.edu
Daniel Herrera      daniel.herrera.842@my.csun.edu
Harut Kulakchian  harut.kulakchian.037@my.csun.edu

2-
Before or After Class Tuesday/Thursday 

3-
Chat Service-
Discord

4-
Project Idea:  
Workout RPG App

Brief Proposal: 
We came up with a project idea of a Workout RPG app. The app will 
track your workouts, but it will also have an RPG character in the app 
that will mimic you. The character will grow stronger as you log your 
workout. For example, if you do pushups and record them in the app 
your RPG character will grow with you. We also want to add a water 
intake feature. For example it will probably give you a boost or extra 
health for every time you drink water.

 Platform: React native
 IDE: VScode
 Backend: Java (SprintBoot)
 Database: postgresql
 Libraries: react-native-maps
 APIs you will access: Google Maps API
 Package manager: Gradle

5-
Team Goals-
Osbaldo Bravo    – Wants to strengthen GitHub skills and help with testing and repo management.
Carlos Martinez  – Want to practice app development and learn about frontend frameworks
Anthony Jimenez  – Hope to also strengthen GitHub skills and learn about ios development and get an understanding of different languages not previously used yet. 
Daniel Herrera   – Wants to learn how to do backend programming as well as using different tools such as AI or different programming languages to expand their library.
Harut Kulakchian – Wants learn application development and the tools used for it as well as wanting experience working in a team for a project.


6-
Osbaldo Bravo    - Tester/Researcher/Repo Master/Helper/Project Manager
Carlos Martinez  - Researcher/Database Developer
Anthony Jimenez  - Tester/User Experience
Daniel Herrera   - Frontend/Editor/User Experience
Harut Kulakchian - Application Developer/Lead Architect 

7-
GitHub Names-
Osbaldo Bravo    - Osbaldoo
Carlos Martinez  - carlosm959
Anthony Jimenez  - An7hony5252
Daniel Herrera   - danielHerrera144
Harut Kulakchian - HarutK-L


8-
Wiki Page


9-
Add a page to your wiki titled "Project Description"-
