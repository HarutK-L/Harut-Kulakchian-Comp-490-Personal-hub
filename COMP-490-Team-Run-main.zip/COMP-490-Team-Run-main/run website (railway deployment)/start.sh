bash
#!/bin/bash
echo "🚀 Starting FitQuest server..."
node server.js